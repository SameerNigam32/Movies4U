const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();
const port = 3000;

mongoose.connect('mongodb://localhost:27017/Moviez4U', { useNewUrlParser: true, useUnifiedTopology: true });
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

const userSchema = new mongoose.Schema({
    name: String,
    email: String,
    phone: String
});
const User = mongoose.model('User', userSchema);

app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/str3.html');
});

app.post('/submit', (req, res) => {
    const name = req.body.name.trim();
    const email = req.body.email.trim();
    const phone = req.body.phone.trim();

    if (name === "" || email === "") {
        return res.status(400).send("Name and email fields are required.");
    }

    const newUser = new User({
        name: name,
        email: email,
        phone: phone
    });

    newUser.save((err, savedUser) => {
        if (err) {
            console.error(err);
            return res.status(500).send("Error saving user.");
        }
        res.send("User saved successfully!");
    });
});

app.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}`);
});
